<?php

 require_once "C:/wamp64/www/tiendawood/conexion.php";
 require_once "C:/wamp64/www/tiendawood/metodosCrud.php";

 $Codigo=$_POST['codigo'];
 $Nombre=$_POST['producto'];
 $Cantidad=$_POST['cantidad'];
 $Precio_unitario=$_POST['precio'];
 $foto=$_POST['foto'];
 $id=$_POST['id'];

 $datos=array(
	  $Codigo,
	  $Nombre,
	  $Cantidad,
	  $Precio_unitario,
	  $foto,
	  $id
 );

 $obj= new metodos();
 if($obj->actualizaDatosProducto($datos)==1){
     header("location:../index.php");
 }else{
     echo "fallo al agregar";
 }
 ?> 
