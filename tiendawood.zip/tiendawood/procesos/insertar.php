<?php
 require_once "C:/wamp64/www/tiendawood/conexion.php";
 require_once "C:/wamp64/www/tiendawood/metodosCrud.php";
 
 $Codigo=$_POST['codigo'];
 $Nombre=$_POST['producto'];
 $Cantidad=$_POST['cantidad'];
 $Precio_unitario=$_POST['precio'];
 $foto=$_POST['foto'];

 $datos=array(
	  $Codigo,
	  $Nombre,
	  $Cantidad,
	  $Precio_unitario,
	  $foto
 );

    $obj= new metodos();
    if($obj->insertarDatosProducto($datos)==1){
      //header("Location:".$_SERVER['HTTP_REFERER']);
      header("location:../registro.php");
    }else{
      echo "fallo al agregar";
    }
 ?> 

