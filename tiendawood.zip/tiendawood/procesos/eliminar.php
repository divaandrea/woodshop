<?php

 require_once "C:/wamp64/www/tiendawood/conexion.php";
 require_once "C:/wamp64/www/tiendawood/metodosCrud.php";

 $id=$_POST['id'];

 $obj= new metodos();
 if($obj->eliminarDatosProducto($id)==1){
    header("location:../registra.php");
 }else{
    echo "fallo al agregar";
 }
 ?> 