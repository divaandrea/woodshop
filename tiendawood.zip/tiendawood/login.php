<div class="container">
  <div class="row">
  	<form action="registro.php" method="post">
		<font color="#FFFFFF"><b>Usuario</b></font>
		<input type="text" placeholder="Digite Usuario"  id="usuario"  name="usuario">
		<font color="#FFFFFF"><b>password</b></font>
		<input type="password" placeholder="Digite Password" id="password"  name="password">
		<button class="btn btn-success"><i class="fa fa-user-o"></i>Entrar</button>
	</form>
   </div>
</div>
