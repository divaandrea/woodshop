<?php
 class metodos{

	public function validarUsuario($sql){
		 $c= new conectar();
		 $conexion=$c->conexion();
		 $result=mysqli_query($conexion,$sql);
		 return mysqli_fetch_all($result,MYSQLI_ASSOC);
	}

	public function mostrarDatos($sql){
		 $c= new conectar();
		 $conexion=$c->conexion();
		 $result=mysqli_query($conexion,$sql);
		 return mysqli_fetch_all($result,MYSQLI_ASSOC);
	}

	public function insertarDatosProducto($datos){
		 $c= new conectar();
		 $conexion=$c->conexion();
		 $sql="INSERT into producto (Codigo,Nombre,Cantidad,Precio_unitario,foto)
		           values ('".$datos[0]."','".$datos[1]."','".$datos[2]."',
		                   '".$datos[3]."','".$datos[4]."')";
		 return $result=mysqli_query($conexion,$sql);
	 } 

	 public function eliminarDatosProducto($id){
		 $c= new conectar();
		 $conexion=$c->conexion();
		 $sql="DELETE from producto where idProducto='".$id."'";
		 return $result=mysqli_query($conexion,$sql);
	 }

	 public function actualizaDatosProducto($datos){
		 $c= new conectar();
		 $conexion=$c->conexion();
		 $sql="UPDATE producto 
		        set Codigo='".$datos[0]."',
				    Nombre='".$datos[1]."',
				    Cantidad='".$datos[2]."',
				    Precio_unitario='".$datos[3]."',
					foto='".$datos[4]."'
				 where idProducto='".$datos[5]."'";
		 return $result=mysqli_query($conexion,$sql);
	 }

	 
 }
 ?> 
